"""
Program Description: This program takes a given DNA sequence translates it to a protein sequence.

Author:
"""

import helper

def transcription(dna_sequence):
    complement = ''

    # Create the Base Pair Complement

    # Replace Thymine with Uracil

    return mrna

def translate(mrna):
    protein = ''

    # Split mrna into nucleotide triplets

    # Replace Triplets with Amino Acids

    return protein


dna = 'TACGCAGAAAAAAATCAGCGGGGTTGTTGGTCATTAGTCTGAATT'
